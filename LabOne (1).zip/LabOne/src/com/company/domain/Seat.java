package com.company.domain;

public class Seat implements PersonSeat {
    private String name;
    private String brand;
    private String color;
    private double price;

    public Seat() {
    }

    public Seat(String name, String brand, String color, double price) {
        this.name = name;
        this.brand = brand;
        this.color = color;
        this.price = price;
    }

    public Seat(String[] line) {
        this.name = line[1];
        this.brand = line[2];
        this.color = line[3];
        this.price = Double.parseDouble(line[4]);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Name: ");
        builder.append(name);
        builder.append(" | Brand: ");
        builder.append(brand);
        builder.append(" | Color: ");
        builder.append(color);
        builder.append(" | Price: ");
        builder.append(price);
        return builder.toString();
    }
}
