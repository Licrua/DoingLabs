package com.company.domain;

import java.io.Serializable;

public interface PersonSeat extends Serializable {
    default void print(){
        System.out.println(toString());
    }
}
