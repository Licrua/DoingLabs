package com.company.domain;

public class CarSeat extends Seat{
    private String chair;
    private String degree;
    private int stage = 0;
    private boolean isISOFIXCompatible;

    public CarSeat() {
    }

    public CarSeat(String name, String brand, String color, double price, String chair, String degree, int stage, boolean isISOFIXCompatible) {
        super(name, brand, color, price);
        this.chair = chair;
        this.degree = degree;
        this.stage = stage;
        this.isISOFIXCompatible = isISOFIXCompatible;
    }

    public CarSeat(String[] line) {
        super(line);
        this.chair = line[5];
        this.degree = line[6];
        this.stage = Integer.parseInt(line[7]);
        this.isISOFIXCompatible = Boolean.parseBoolean(line[8]);
    }

    public String getChair() {
        return chair;
    }

    public void setChair(String chair) {
        this.chair = chair;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    public int getStage() {
        return stage;
    }

    public void setStage(int stage) {
        this.stage = stage;
    }

    public boolean isISOFIXCompatible() {
        return isISOFIXCompatible;
    }

    public void setISOFIXCompatible(boolean isISOFIXCompatible) {
        this.isISOFIXCompatible = isISOFIXCompatible;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Car Seat: ");
        builder.append(super.toString());
        builder.append("\t | Chair: ");
        builder.append(chair);
        builder.append("\t | Degree: ");
        builder.append(degree);
        builder.append("\t | Stage: ");
        builder.append(stage);
        builder.append("\t | ISOFIX Compatible: ");
        builder.append(isISOFIXCompatible);
        return builder.toString();
    }
}
