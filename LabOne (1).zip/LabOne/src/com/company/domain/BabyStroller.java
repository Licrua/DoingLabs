package com.company.domain;

public class BabyStroller extends Seat{
    private int weightCapacity;
    private boolean recliningSeat;
    private boolean adjustableHandlebar;
    private String suspensionType;

    public BabyStroller() {
    }

    public BabyStroller(String name, String brand, String color, double price, int weightCapacity, boolean recliningSeat, boolean adjustableHandlebar, String suspensionType) {
        super(name, brand, color, price);
        this.weightCapacity = weightCapacity;
        this.recliningSeat = recliningSeat;
        this.adjustableHandlebar = adjustableHandlebar;
        this.suspensionType = suspensionType;
    }

    public BabyStroller(String[] line) {
        super(line);
        this.weightCapacity = Integer.parseInt(line[5]);
        this.recliningSeat = Boolean.parseBoolean(line[6]);
        this.adjustableHandlebar = Boolean.parseBoolean(line[7]);
        this.suspensionType = line[8];
    }

    public int getWeightCapacity() {
        return weightCapacity;
    }

    public void setWeightCapacity(int weightCapacity) {
        this.weightCapacity = weightCapacity;
    }

    public boolean isRecliningSeat() {
        return recliningSeat;
    }

    public void setRecliningSeat(boolean recliningSeat) {
        this.recliningSeat = recliningSeat;
    }

    public boolean isAdjustableHandlebar() {
        return adjustableHandlebar;
    }

    public void setAdjustableHandlebar(boolean adjustableHandlebar) {
        this.adjustableHandlebar = adjustableHandlebar;
    }

    public String getSuspensionType() {
        return suspensionType;
    }

    public void setSuspensionType(String suspensionType) {
        this.suspensionType = suspensionType;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Baby Stroller: ");
        builder.append(super.toString());
        builder.append("\t | Weight Capacity: ");
        builder.append(weightCapacity);
        builder.append("\t | Reclining Seat: ");
        builder.append(recliningSeat);
        builder.append("\t | Adjustable Handlebar: ");
        builder.append(adjustableHandlebar);
        builder.append("\t | Suspension Type: ");
        builder.append(suspensionType);
        return builder.toString();
    }
}
