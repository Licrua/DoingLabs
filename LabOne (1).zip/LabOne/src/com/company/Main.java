package com.company;

import com.company.domain.BabyStroller;
import com.company.domain.CarSeat;
import com.company.domain.PersonSeat;
import com.company.domain.Seat;
import com.company.util.CVSFileReader;
import com.company.util.JournalWrite;
import com.company.util.SerializationUtils;

import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        // write your code here
        if (args.length < 2) {
            JournalWrite.printParameters(false);
            System.out.println("You must specify data file name and serialize file name!");
            return;
        } else
            JournalWrite.printParameters(true);
        String fileReader = args[0];
        String binFile = args[1];

        List<String[]> allStrings = CVSFileReader.cvsFileReader(fileReader, ";");
        List<PersonSeat> seats = new ArrayList<>();

        for (String[] line : allStrings) {
            if (line[0].equals("0")) {
                seats.add(new CarSeat(line));
                JournalWrite.printAddSeat(seats.get(seats.size() - 1));
            } else {
                seats.add(new BabyStroller(line));
                JournalWrite.printAddSeat(seats.get(seats.size() - 1));
            }
        }

        for (PersonSeat seat : seats
        ) {
            System.out.println(seat.toString());
        }

        SerializationUtils.serialize(seats, binFile);
        List<PersonSeat> newSeats = (List<PersonSeat>) SerializationUtils.deserialize(binFile);

        System.out.println("New:");
        for (PersonSeat seat : newSeats
        ) {
            System.out.println(seat.toString());
        }
    }

}
