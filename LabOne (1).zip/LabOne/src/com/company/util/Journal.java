package com.company.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public abstract class Journal {
    private static final File journalFile = new File("Журнал.txt");

    public static void print(String text) {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm");
        String formattedDateTime = LocalDateTime.now().format(dateTimeFormatter);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(journalFile, true))) {
            writer.write(formattedDateTime);
            writer.newLine();
            writer.write(text);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
