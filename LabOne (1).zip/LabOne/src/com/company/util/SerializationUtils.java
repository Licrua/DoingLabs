package com.company.util;

import java.io.*;

public class SerializationUtils {
    public static void serialize(Object obj, String fileName) {
        try (FileOutputStream fileOut = new FileOutputStream(fileName);
             ObjectOutputStream out = new ObjectOutputStream(fileOut)) {
            out.writeObject(obj);
            System.out.println("Object serialized and saved to " + fileName);
            JournalWrite.printSerialize(true);
        } catch (IOException e) {
            JournalWrite.printSerialize(false);
            e.printStackTrace();
        }
    }

    public static Object deserialize(String fileName) {
        Object obj = null;
        try (FileInputStream fileIn = new FileInputStream(fileName);
             ObjectInputStream in = new ObjectInputStream(fileIn);) {
            obj = in.readObject();
            System.out.println("Object deserialized from " + fileName);
            JournalWrite.printDeserialize(true);
            //Запись в журнал
            return obj;
        } catch (IOException e) {
            JournalWrite.printDeserialize(false);
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            JournalWrite.printDeserialize(false);
            e.printStackTrace();
        }
        return obj;
    }
}
