package com.company.util;

import com.company.domain.PersonSeat;
import com.company.domain.Seat;

public class JournalWrite extends Journal {

    public static void printParameters(boolean in) {
        if (in)
            print("The incoming parameters are specified correctly!");
        else
            print("The incoming parameters are specified incorrectly!");
    }

    public static void printReadCSV(boolean in) {
        if (in)
            print("Reading the cvs file succeeded!");
        else
            print("Reading the cvs file failed!");
    }

    public static void printSerialize(boolean in) {
        if (in)
            print("Serialization succeeded!");
        else
            print("Serialization failed!");
    }

    public static void printDeserialize(boolean in) {
        if (in)
            print("Deserialization succeeded");
        else
            print("Deserialization failed!");
    }

    public static void printAddSeat(PersonSeat seat) {
        if (seat != null)
            print("Adding succeeded:\t " + seat.toString());
        else
            print("Adding failed!");
    }

}
