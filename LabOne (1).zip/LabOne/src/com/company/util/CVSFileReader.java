package com.company.util;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class CVSFileReader {
    public static List<String[]> cvsFileReader(String fileName, String separator) {
        List<String[]> allStrings = new ArrayList<>();
        File fileReader = new File(fileName);
        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(fileReader))) {
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                System.out.println(line);
                //Запись в журнал
                String[] allLines = line.split(separator);
                allStrings.add(allLines);
            }
            JournalWrite.printReadCSV(true);
        } catch (FileNotFoundException e) {
            JournalWrite.printReadCSV(false);
            e.printStackTrace();
        } catch (IOException e) {
            JournalWrite.printReadCSV(false);
            e.printStackTrace();
        }
        return allStrings;
    }

}
